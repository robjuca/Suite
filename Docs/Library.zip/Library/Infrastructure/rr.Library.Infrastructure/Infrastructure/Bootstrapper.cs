﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.ComponentModel.Composition.Primitives;
using System.Linq;
using System.Windows;

using Caliburn.Micro;
//---------------------------//

namespace rr.Library.Infrastructure
{
  public abstract class TBootstrapper<R> : BootstrapperBase
  {
    #region Constructor
    public TBootstrapper ()
    {
      m_AggregateCatalog = new AggregateCatalog ();

      Initialize ();
    }
    #endregion

    #region Members
    protected virtual void ConfigureCatalog ()
    {
    }

    protected void AddToCatalog (AssemblyCatalog catalog)
    {
      m_AggregateCatalog.Catalogs.Add (catalog);
    } 
    #endregion

    #region Overrides
    protected override void Configure ()
    {
      //this app
      m_AggregateCatalog.Catalogs.Add (new AggregateCatalog (AssemblySource.Instance.Select (x => new AssemblyCatalog (x)).OfType<ComposablePartCatalog> ()));

      m_Container = new CompositionContainer (m_AggregateCatalog);

      var batch = new CompositionBatch ();

      batch.AddExportedValue<IWindowManager> (new WindowManager ());
      batch.AddExportedValue<IEventAggregator> (new EventAggregator ());
      batch.AddExportedValue (m_Container);

      m_Container.Compose (batch);

      ConfigureCatalog ();
    }

    protected override object GetInstance (Type serviceType, string key)
    {
      string contract = string.IsNullOrEmpty (key) ? AttributedModelServices.GetContractName (serviceType) : key;
      var exports = m_Container.GetExportedValues<object> (contract);

      if (exports.Any ()) {
        return (exports.First ());
      }

      throw (new Exception (string.Format ("Could not locate any instances of contract {0}.", contract)));
    }

    protected override IEnumerable<object> GetAllInstances (Type serviceType)
    {
      return (m_Container.GetExportedValues<object> (AttributedModelServices.GetContractName (serviceType)));
    }

    public IEnumerable<object> GetAllInstances (string key)
    {
      return (m_Container.GetExportedValues<object> (key));
    }

    protected override void BuildUp (object instance)
    {
      m_Container.SatisfyImportsOnce (instance);
    }

    protected override void OnStartup (object sender, StartupEventArgs e)
    {
      base.OnStartup (sender, e);

      DisplayRootViewFor<R> ();
    }

    protected override void OnUnhandledException (object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
    {
      var msg = rr.Library.Helper.THelper.ExceptionStringFormat ("Warning", e.Exception);

      e.Handled = true;
      MessageBox.Show (msg, "An FATAL ERROR has occurred - Application will ABORT!", MessageBoxButton.OK);

      if (Application.Current.NotNull ()) {
        Application.Current.Shutdown ();
      }
    }
    #endregion

    #region Fields
    readonly AggregateCatalog                         m_AggregateCatalog;
    CompositionContainer                              m_Container;
    #endregion
  };
  //---------------------------//

}  // namespace