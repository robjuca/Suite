﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using Caliburn.Micro;
//---------------------------//

namespace rr.Library.Infrastructure
{
  public interface IModule
  {
    void          Initialize ();
  };
  //---------------------------//

}  // namespace