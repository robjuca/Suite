﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Collections.Concurrent;
using System.Threading.Tasks;

using Caliburn.Micro;

using rr.Library.Types;
//---------------------------//

namespace rr.Library.Infrastructure
{
  public abstract class TPresentation
  {
    #region Property
    public IViewModel ViewModel
    {
      get
      {
        return (m_ViewModel);
      }

      set
      {
        if (value != null) {
          m_ViewModel = value;
          RequestPresentationCommand (m_ViewModel);
        }
      }
    } 
    #endregion

    #region Constructor
    public TPresentation ()
    {
    }

    public TPresentation (IEventAggregator events, bool subscribe = true)
    {
      m_Events = events;

      if (subscribe) {
        m_Events.Subscribe (this);
      }
    }

    static TPresentation ()
    {
      //m_Messages = new BlockingCollection<object> (5000);
      m_Fifo = new ConcurrentQueue<object> ();
    }
    #endregion

    #region Members
    public void RequestPresentationCommand (IViewModel viewModel)
    {
      if (DelegateCommand == null) {
        PresentationCommand (viewModel);
      }

      else {
        viewModel.SetPresentationCommand (DelegateCommand);
      }
    }

    public void EventSubscribe (IViewModel viewModel)
    {
      if (Events != null) {
        Events.Subscribe (viewModel);
      }
    }

    protected void Publish (object message)
    {
      if ((Events != null) && (message != null)) {
        Events.PublishOnUIThread (message);
      }
    }

    protected void PublishAsync (object message)
    {
      if ((Events != null) && (message != null)) {
        PublishAsync (Events, message).ContinueWith (delegate
        {
          // ??
        });
      }
    }

    protected void PublishInvoke (object message)
    {
      if ((Events != null) && (message != null)) {
        //m_Messages.Add (message);
        m_Fifo.Enqueue (message);

        // Delegate for consuming 
        async void act ()
        {
          //while (m_Messages.TryTake (out object someMessage)) {
          //  Events.PublishOnUIThread (someMessage);
          //}

          while (m_Fifo.TryDequeue (out object someMessage)) {
            await Events.PublishOnUIThreadAsync (someMessage);
          }
        }

        Parallel.Invoke (act);
      }
    }
    #endregion

    #region Virtual
    protected virtual void PresentationCommand (IViewModel viewModel)
    {
    }
    #endregion

    #region Property
    protected IPresentationCommand DelegateCommand
    {
      get;
      set;
    }

    protected IEventAggregator Events
    {
      get
      {
        return (m_Events);
      }
      
      private set
      {
        m_Events = value;
      }
    }

    protected string TypeName
    {
      get;
      set;
    }

    protected TTypeInfo TypeInfo
    {
      get
      {
        return (new TTypeInfo (TypeName));
      }
    }
    #endregion

    #region Fields
    IEventAggregator                                  m_Events;
    IViewModel                                        m_ViewModel;
    //static BlockingCollection<object>                 m_Messages;
    static ConcurrentQueue<object>                    m_Fifo;
    #endregion

    #region Support
    static async Task PublishAsync (IEventAggregator events, object message)
    {
      try {
        Task task = events.PublishOnUIThreadAsync (message);

        if (task == await Task.WhenAny (task)) {
          // do nothing
        }
      }

      catch (Exception) {
      }
    } 
    #endregion
  };
  //---------------------------//

}  // namespace