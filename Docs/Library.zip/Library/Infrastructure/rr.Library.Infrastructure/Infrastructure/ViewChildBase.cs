﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
//---------------------------//

namespace rr.Library.Infrastructure
{
  public partial class ViewChildBase : System.Windows.Controls.UserControl
  {
    #region Constructor
    public ViewChildBase ()
    {
      Loaded += OnLoaded;
    }
    #endregion

    #region View Event
    void OnLoaded (object sender, System.Windows.RoutedEventArgs e)
    {
      var viewModel = Caliburn.Micro.IoC.GetInstance (null, Name);

      if (viewModel != null) {
        Caliburn.Micro.ViewModelBinder.Bind (viewModel, this, null);
      }
    }
    #endregion
  }
  //---------------------------//

}  // namespace