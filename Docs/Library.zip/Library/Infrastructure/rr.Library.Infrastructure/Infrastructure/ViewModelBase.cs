﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;

using rr.Library.Types;
//---------------------------//

namespace rr.Library.Infrastructure
{
  public abstract class TViewModelBase<TModel> : TViewModelScreen, IViewModel
  {
    #region Property
    public TModel Model
    {
      get;
      private set;
    }

    public object Parameter
    {
      get;
      set;
    }
    #endregion

    #region Constructor
    protected TViewModelBase (TModel model)
      : base ()
    {
      Model = model;
    }
    #endregion

    #region IViewModel Members
    public event EventHandler Loaded;

    public bool IsLoaded
    {
      get
      {
        return (m_IsLoaded);
      }

      protected set
      {
        m_IsLoaded = value;

        if (IsLoaded) {
          Loaded?.Invoke (this, EventArgs.Empty);
        }
      }
    }

    public void SetPresentationCommand (IPresentationCommand presentationCommand)
    {
      PresentationCommand = presentationCommand;
    }
    #endregion

    #region Members
    protected void RaiseChanged ()
    {
      NotifyOfPropertyChange ("Model");
    }
    #endregion

    #region Property
    protected IPresentationCommand PresentationCommand
    {
      get;
      set;
    }

    protected string TypeName
    {
      get;
      set;
    }

    protected TTypeInfo TypeInfo
    {
      get
      {
        return (new TTypeInfo (TypeName));
      }
    }
    #endregion

    #region Fields
    bool                                    m_IsLoaded;
    #endregion
  };
  //---------------------------//

  //----- TViewModelScreen
  public abstract class TViewModelScreen : Caliburn.Micro.Screen
  {
    #region Constructor
    protected TViewModelScreen ()
    {
    }
    #endregion
  };
  //---------------------------//

}  // namespace