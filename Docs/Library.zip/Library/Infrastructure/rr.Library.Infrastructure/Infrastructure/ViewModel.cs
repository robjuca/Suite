﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

using Caliburn.Micro;

using rr.Library.Types;
//---------------------------//

namespace rr.Library.Infrastructure
{
  //----- TViewModel<TModel>
  public class TViewModel<TModel> : TViewModelPresentation
  {
    #region Property
    public TModel Model
    {
      get;
      private set;
    }
    #endregion

    #region Constructor
    public TViewModel (TModel model)
    {
      Model = model;
    }

    public TViewModel (FrameworkElement view, TModel model)
    {
      FrameworkElementView = view;
      Model = model;
    }
    #endregion

    #region Members
    protected void RaiseChanged ()
    {
      NotifyOfPropertyChange (() => Model);
    }

    protected void UpdateDataContext ()
    {
      if (FrameworkElementView != null) {
        FrameworkElementView.DataContext = FrameworkElementView.DataContext ?? this;
      }
    }

    protected Storyboard FindStoryboard (string resourceName)
    {
      if (FrameworkElementView != null) {
        if (FrameworkElementView.Resources.Contains (resourceName)) {
          return (FrameworkElementView.Resources [resourceName] as Storyboard);
        }
      }

      return (null);
    }

    protected void BeginStoryboard (string resourceName)
    {
      var storyboard = FindStoryboard (resourceName);

      if (storyboard is Storyboard) {
        storyboard.Begin ();
      }
    }

    protected void GoToVisualState (string stateName)
    {
      if (FrameworkElementView != null) {
        VisualStateManager.GoToState ((Control) FrameworkElementView, stateName, true);
      }
    }

    protected void ShowViewAnimation ()
    {
      if (ViewState == TViewState.Hide) {
        ViewState = TViewState.Show;
        GoToVisualState ("ShowViewAnimation");
      }
    }

    protected void HideViewAnimation ()
    {
      if (ViewState == TViewState.Show) {
        ViewState = TViewState.Hide;
        GoToVisualState ("HideViewAnimation");
      }
    }
    #endregion

    #region Property
    protected FrameworkElement FrameworkElementView
    {
      get;
      set;
    }
    
    protected string TypeName
    {
      get;
      set;
    }

    protected TTypeInfo TypeInfo
    {
      get
      {
        return (new TTypeInfo (TypeName));
      }
    }
    #endregion
  }
  //---------------------------//

  //----- TViewModelPresentation
  public class TViewModelPresentation : TViewModel, IViewModel
  {
    #region Constructor
    public TViewModelPresentation ()
    {
      ViewState = TViewState.Hide;
    }
    #endregion

    #region IViewModel Members
    public event EventHandler Loaded;

    public bool IsLoaded
    {
      get
      {
        return (m_IsLoaded);
      }

      protected set
      {
        m_IsLoaded = value;

        if (IsLoaded) {
          Loaded?.Invoke (this, EventArgs.Empty);
        }
      }
    }

    public void SetPresentationCommand (IPresentationCommand presentationCommand)
    {
      PresentationCommand = presentationCommand;

      Execute.OnUIThreadAsync (AllDone);
      Execute.OnUIThreadAsync (Initialize);
    }
    #endregion

    #region Overrides
    protected virtual void Initialize ()
    {
    }

    protected virtual void AllDone ()
    {
    }
    #endregion

    #region Property
    protected IPresentationCommand PresentationCommand
    {
      get;
      set;
    }

    protected TViewState ViewState
    {
      get;
      set;
    }
    #endregion

    #region Fields
    bool                                    m_IsLoaded;
    #endregion
  };
  //---------------------------//

  //----- TViewModel
  public class TViewModel : PropertyChangedBase
  {
    #region Constructor
    public TViewModel ()
    {
    }
    #endregion
  }
  //---------------------------//

}  // namespace