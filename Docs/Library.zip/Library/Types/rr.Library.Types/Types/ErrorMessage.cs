﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
//---------------------------//

namespace rr.Library.Types
{
  public class TErrorMessage
  {
    #region Property
    public string Title
    {
      get;
      set;
    }

    public string Caption
    {
      get;
      set;
    }

    public string Message
    {
      get;
      set;
    }

    public TSeverity Severity
    {
      get;
      set;
    }
    #endregion

    #region Constructor
    public TErrorMessage (string title, string caption, string message)
      : this ()
    {
      Title = title;
      Caption = caption;
      Message = message;
    }

    public TErrorMessage (TErrorMessage alias)
      : this ()
    {
      CopyFrom (alias);
    }

    TErrorMessage ()
    {
      Title = string.Empty;
      Caption = string.Empty;
      Message = string.Empty;
      Severity = TSeverity.None;
    }
    #endregion

    #region Members
    public void CopyFrom (TErrorMessage alias)
    {
      if (alias != null) {
        Title = alias.Title;
        Caption = alias.Caption;
        Message = alias.Message;
        Severity = alias.Severity;
      }
    }

    public bool IsSeverity (TSeverity severity)
    {
      return (Severity == severity);
    }
    #endregion

    #region Property
    static public TErrorMessage CreateDefault => (new TErrorMessage ()); 
    #endregion
  };
  //---------------------------//

}
