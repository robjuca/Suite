﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Windows.Input;
//---------------------------//

namespace rr.Library.Types
{
  public class DelegateCommand : ICommand
  {
    #region Constructor
    public DelegateCommand (Action execute)
      : this (execute, null)
    {
    }

    public DelegateCommand (Action execute, Predicate<object> canExecute)
    {
      if (execute == null) {
        throw new ArgumentNullException ("execute");
      }

      m_Execute = new Action (execute);

      if (canExecute != null) {
        m_CanExecute = new Predicate<object> (canExecute);
      }
    }
    #endregion

    #region ICommand Members
    public event EventHandler CanExecuteChanged;

    public bool CanExecute (object parameter)
    {
      if (m_CanExecute == null) {
        return true;
      }

      return (m_CanExecute (parameter));
    }

    public void Execute (object parameter)
    {
      m_Execute ();
    }
    #endregion

    #region Members
    public void RaiseCanExecuteChanged ()
    {
      if (CanExecuteChanged != null) {
        CanExecuteChanged (this, null);
      }
    } 
    #endregion

    #region Fields
    readonly Predicate<object>                        m_CanExecute;
    readonly Action                                   m_Execute; 
    #endregion
  };
  //---------------------------//

  public class DelegateCommand<T> : ICommand
  {
    #region onstructor
    public DelegateCommand (Action<T> execute)
      : this (execute, null)
    {
    }

    public DelegateCommand (Action<T> execute, Predicate<T> canExecute)
    {
      if (execute == null) {
        throw new ArgumentNullException ("execute");
      }

      m_Execute = new Action<T> (execute);

      if (canExecute != null) {
        m_CanExecute = new Predicate<T> (canExecute);
      }
    } 
    #endregion

    #region ICommand Members
    public event EventHandler CanExecuteChanged;

    public bool CanExecute (object parameter)
    {
      if (m_CanExecute == null) {
        return (true);
      }

      return (m_CanExecute ((T) parameter));
    }

    public void Execute (object parameter)
    {
      if (m_Execute != null) {
        m_Execute ((T) parameter);
      }
    }
    #endregion

    #region Members
    public void RaiseCanExecuteChanged ()
    {
      if (CanExecuteChanged != null) {
        CanExecuteChanged (this, null);
      }
    }
    #endregion

    #region Fields
    readonly Predicate<T>                             m_CanExecute;
    readonly Action<T>                                m_Execute; 
    #endregion
  };
  //---------------------------//

}  // namespace