﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
//---------------------------//

namespace rr.Library.Types
{
  public class TDatabaseAuthentication : TDatabaseConnectionData
  {
    #region Property
    public TAuthentication Authentication
    {
      get;
      private set;
    }

    public bool IsActive
    {
      get;
      private set;
    }

    public bool HasConnectionString
    {
      get
      {
        return (string.IsNullOrEmpty (RequestConnectionString ()).Equals (false));
      }
    }
    #endregion

    #region Constructor
    TDatabaseAuthentication (TAuthentication authentication)
    {
      Authentication = authentication;

      IsActive = false;
    }
    #endregion

    #region Members
    public string RequestConnectionString ()
    {
      string connectionString = string.Empty;

      if (ValidateConnection (Authentication)) {
        switch (Authentication) {
          case TAuthentication.SQL:
            connectionString = $"Server={DatabaseServer};Initial Catalog={DatabaseName};User Id={UserId};Password={UserPassword}";
            break;

          case TAuthentication.Windows:
            connectionString = $"Server={DatabaseServer};Initial Catalog={DatabaseName}";
            break;
        }
      }

      return (connectionString);
    }

    public bool Activate (TAuthentication authentication)
    {
      IsActive = Authentication.Equals (authentication);

      return (IsActive);
    }

    public void Change (TDatabaseAuthentication alias)
    {
      base.CopyFrom (alias);
    }

    public void CopyFrom (TDatabaseAuthentication alias)
    {
      if (alias != null) {
        base.CopyFrom (alias);

        Authentication = alias.Authentication;
        IsActive = alias.IsActive;
      }
    }
    #endregion

    #region Static
    public static TDatabaseAuthentication Create (TAuthentication authentication) => new TDatabaseAuthentication (authentication);

    public static TDatabaseAuthentication CreateDefault => new TDatabaseAuthentication (TAuthentication.None); 
    #endregion
  };
  //---------------------------//

  //----- TDatabaseConnectionData
  public abstract class TDatabaseConnectionData
  {
    #region Property
    public string DatabaseServer
    {
      get;
      set;
    }

    public string DatabaseName
    {
      get;
      set;
    }

    public string UserId
    {
      get;
      set;
    }

    public string UserPassword
    {
      get;
      set;
    }
    #endregion

    #region Constructor
    public TDatabaseConnectionData ()
    {
      DatabaseName = string.Empty;
      DatabaseServer = string.Empty;
      UserId = string.Empty;
      UserPassword = string.Empty;
    }
    #endregion

    #region Members
    public bool ValidateConnection (TAuthentication authentication)
    {
      if (string.IsNullOrEmpty (DatabaseName) || string.IsNullOrEmpty (DatabaseServer)) {
        return (false);
      }

      if (authentication.Equals (TAuthentication.SQL)) {
        if (string.IsNullOrEmpty (UserId) || string.IsNullOrEmpty (UserPassword)) {
          return (false);
        }
      }

      return (true);
    }

    public void Apply ()
    {
      // zap space
      DatabaseServer = DatabaseServer.Replace (" ", "").Replace (";", "");
      DatabaseName = DatabaseName.Replace (" ", "").Replace (";", "");
      UserId = UserId.Replace (" ", "").Replace (";", "");
      UserPassword = UserPassword.Replace (" ", "").Replace (";", "");
    }

    public void CopyFrom (TDatabaseConnectionData alias)
    {
      if (alias != null) {
        DatabaseServer = alias.DatabaseServer;
        DatabaseName = alias.DatabaseName;
        UserId = alias.UserId;
        UserPassword = alias.UserPassword;

        Apply ();
      }
    }
    #endregion
  };
  //---------------------------//

}  // namespace