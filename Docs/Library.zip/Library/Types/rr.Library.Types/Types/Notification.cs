﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
//---------------------------//

namespace rr.Library.Types
{
  public class TNotification<T> : NotificationObject
  {
    #region Property
    public T Notify
    {
      get
      {
        return (m_Notify);
      }

      set
      {
        m_Notify = value;
        RaisePropertyChanged (() => this.Notify);
      }
    } 
    #endregion

    #region Constructor
    public TNotification (T notify)
    {
      m_Notify = notify;
    } 
    #endregion

    #region Fields
    T                                       m_Notify;
    #endregion
  };
  //---------------------------//

}  // namespace