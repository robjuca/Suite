﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
//---------------------------//

namespace rr.Library.Converter
{
  public class TVisibilityRatingConverter : IValueConverter
  {
    #region IValueConverter Members
    public object Convert (object value, Type targetType, object parameter, CultureInfo culture)
    {
      int rating = (int) value;
      int pos = Int32.Parse (parameter as string, System.Globalization.CultureInfo.InvariantCulture);

      if (pos == 0) {
        return ((rating == 0) ? Visibility.Visible : Visibility.Collapsed);
      }

      else {
        return ((rating >= pos) ? Visibility.Visible : Visibility.Collapsed);
      }
    }

    public object ConvertBack (object value, Type targetType, object parameter, CultureInfo culture)
    {
      throw new NotImplementedException ("Not Implemented");
    }
    #endregion
  };
  //---------------------------//

}  // namespace