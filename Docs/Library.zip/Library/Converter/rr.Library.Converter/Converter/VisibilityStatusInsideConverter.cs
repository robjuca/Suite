﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author:     Roberto Oliveira Jucá (rrSoft@pobox.com)
----------------------------------------------------------------*/

//----- Include
using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

using rr.Library.Types;
//---------------------------//

namespace rr.Library.Converter
{
  public class TVisibilityStatusInsideConverter : IValueConverter
  {
    #region IValueConverter Members
    public object Convert (object value, Type targetType, object parameter, CultureInfo culture)
    {
      return (((TStatus) value == TStatus.Inside) ? Visibility.Visible : Visibility.Collapsed);
    }

    public object ConvertBack (object value, Type targetType, object parameter, CultureInfo culture)
    {
      throw new NotImplementedException ("Not Implemented");
    }
    #endregion
  };
  //---------------------------//

} // namespace