﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
//---------------------------//

namespace rr.Library.Communication
{
  public sealed class TMessagingEventArgs<T> : EventArgs
  {
    #region Property
    public T Data
    {
      get;
    } 
    #endregion

    #region Constructor
    public TMessagingEventArgs (T data)
    {
      Data = data;
    }
    #endregion
  };
  //---------------------------//

}  // namespace