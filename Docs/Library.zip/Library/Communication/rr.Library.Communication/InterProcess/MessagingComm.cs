﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using XDMessaging;
using XDMessaging.Messages;
//---------------------------//

namespace rr.Library.Communication
{
  public class TMessagingComm<T>
    where T : class
  {
    #region Property
    public T Data
    {
      get; 
    } 
    #endregion

    #region Event
    // Declare the delegate 
    public delegate void HandleEventHandler (object sender, TMessagingEventArgs<T> e);

    // Declare the event.
    public event HandleEventHandler Handle;
    #endregion

    #region Constructor
    public TMessagingComm (T data)
    {
      Data = data;

      m_MessagingClient = new XDMessagingClient ();

      m_Broadcaster = m_MessagingClient.Broadcasters.GetBroadcasterForMode (XDTransportMode.HighPerformanceUI);

      m_Listener = m_MessagingClient.Listeners.GetListenerForMode (XDTransportMode.HighPerformanceUI);
      m_Listener.MessageReceived += OnMessageReceived; // Attach event handler for incoming messages

      // register default channel
      m_Listener.RegisterChannel (DefaultChannel);
    }
    #endregion

    #region Members
    public void Publish (T data)
    {
      m_Broadcaster.SendToChannel (DefaultChannel, data);
    } 
    #endregion

    #region MessageEvent
    void OnMessageReceived (object sender, XDMessageEventArgs messageEventArgs)
    {
      // e.DataGram.Message is the message
      // e.DataGram.Channel is the channel name

      if (messageEventArgs.DataGram.Channel.Equals (DefaultChannel)) {
        TypedDataGram<T> messagingData = messageEventArgs.DataGram;

        var args = new TMessagingEventArgs<T> (messagingData.Message);

        Handle?.Invoke (this, args);
      }
    }
    #endregion

    #region Property
    static string DefaultChannel
    {
      get
      {
        return ("binary");
      }
    } 
    #endregion

    #region Fields
    readonly XDMessagingClient                                  m_MessagingClient;
    readonly IXDBroadcaster                                     m_Broadcaster;
    readonly IXDListener                                        m_Listener;
    #endregion
  };
  //---------------------------//

}  // namespace