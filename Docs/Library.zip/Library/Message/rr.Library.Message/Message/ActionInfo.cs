﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
//---------------------------//

namespace rr.Library.Message
{
  public class TActionInfo<A>
  {
    #region Property
    public A Action
    {
      get;
      private set;
    }
    #endregion

    #region Constructor
    public TActionInfo (A action)
    {
      Action = action;
    }
    #endregion

    #region Members
    public bool IsAction (A action)
    {
      return (Action.Equals (action));
    }
    #endregion
  };
  //---------------------------//

}  // namespace