﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;

using rr.Library.Types;
//---------------------------//

namespace rr.Library.Message
{
  //----- TModuleInfo<S, R>
  public class TModuleInfo<S, R>
  {

    public TModuleInfo<S> Sender
    {
      get;
      set;
    }

    public TModuleInfo<R> Receiver
    {
      get;
      set;
    }

    #region Constructor
    public TModuleInfo (S sender, R receiver)
    {
      Sender = new TModuleInfo<S> (sender);
      Receiver = new TModuleInfo<R> (receiver);
    }
    #endregion

    #region Members
    public void SelectSender (TTypeInfo typeInfo)
    {
      Sender.Select (typeInfo);
    }

    public void SelectReceiver (TTypeInfo typeInfo)
    {
      Receiver.Select (typeInfo);
    } 
    #endregion
  };
  //---------------------------//

  //----- TModuleInfo<M>
  public class TModuleInfo<M>
  {
    #region Property
    public M Name
    {
      get;
      private set;
    }

    public TTypeInfo TypeInfo
    {
      get;
      private set;
    }

    public Guid Id
    {
      get;
      private set;
    }
    #endregion

    #region Constructor
    public TModuleInfo (M module)
      : this ()
    {
      Name = module;
    }

    public TModuleInfo (M module, TTypeInfo typeInfo)
      : this ()
    {
      Name = module;

      TypeInfo.CopFrom (typeInfo);
    }

    protected TModuleInfo ()
    {
      TypeInfo = new TTypeInfo ();

      Id = Guid.NewGuid ();
    }
    #endregion

    #region Members
    public void Select (TTypeInfo typeInfo)
    {
      TypeInfo.CopFrom (typeInfo);
    }

    public void CopyFrom (TModuleInfo<M> alias)
    {
      if (alias != null) {
        Name = alias.Name;
        TypeInfo.CopFrom (alias.TypeInfo);
        Id = alias.Id;
      }
    }

    public bool IsModule (M module)
    {
      return (Name.Equals (module));
    }
    #endregion
  }
  //---------------------------//

}  // namespace