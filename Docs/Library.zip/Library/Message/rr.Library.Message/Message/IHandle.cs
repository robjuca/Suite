﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
//---------------------------//

namespace rr.Library.Message
{
  #region Module
  public interface IHandleMessage<M, A, S, N> : Caliburn.Micro.IHandle<TMessage<M, A, S, N>>
  {
  };
  //---------------------------// 
  #endregion

}  // namespace