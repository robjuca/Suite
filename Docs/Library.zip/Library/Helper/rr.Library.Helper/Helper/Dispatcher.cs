﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Collections.Concurrent;
using System.Threading.Tasks;
//---------------------------//

namespace rr.Library.Helper
{
  #region Data
  public          delegate void ActionArg<A> (A arg);
  #endregion

  public static class TDispatcher
  {
    #region Constructor
    static TDispatcher ()
    {
      m_Fifo = new ConcurrentQueue<TQueueItem> ();
    }
    #endregion

    #region Members
    public static void Invoke (Action action)
    {
      m_Fifo.Enqueue (new TQueueItem (action));

      // Delegate for consuming 
      async void act ()
      {
        while (m_Fifo.TryDequeue (out TQueueItem queueItem)) {
          await Caliburn.Micro.Execute.OnUIThreadAsync (queueItem.Action);
        }
      }

      Parallel.Invoke (act);
    }

    public static void BeginInvoke<A> (ActionArg<A> actionArg, A arg)
    {
      // Delegate for consuming 
      async void act ()
      {
        await System.Windows.Application.Current.Dispatcher.BeginInvoke (actionArg, new object [] { arg });
      }

      Parallel.Invoke (act);
    }
    #endregion

    #region Fields
    static ConcurrentQueue<TQueueItem>                      m_Fifo;
    #endregion

    #region Class
    class TQueueItem
    {
      #region Property
      public Action Action
      {
        get;
      }
      #endregion

      #region Constructor
      public TQueueItem (Action action)
      {
        Action = action;
      }
      #endregion
    }; 
    #endregion
  };
  //---------------------------//

}  // namespace