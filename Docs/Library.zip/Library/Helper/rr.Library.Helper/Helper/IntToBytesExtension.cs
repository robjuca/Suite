﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Collections.Generic;
//---------------------------//

namespace rr.Library.Helper
{
  public static class TIntToBytesExtension
  {
    #region Constructor
    static TIntToBytesExtension ()
    {
      m_Units = new List<string> () { "B", "KB", "MB", "GB", "TB" };
    }
    #endregion

    #region Members
    /// <summary>
    /// Formats the value as a filesize in bytes (KB, MB, etc.)
    /// </summary>
    /// <param name="bytes">This value.</param>
    /// <returns>Filesize and quantifier formatted as a string.</returns>
    public static string ToBytes (this int bytes)
    {
      double pow = Math.Floor ((bytes > 0 ? Math.Log (bytes) : 0) / Math.Log (1024));
      pow = Math.Min (pow, m_Units.Count - 1);

      double value = (double) bytes / Math.Pow (1024, pow);

      return (value.ToString (pow == 0 ? "F0" : "F" + PRECISION.ToString ()) + " " + m_Units [(int) pow]);
    }
    #endregion

    #region Data
    const int PRECISION = 2;
    #endregion

    #region Fields
    static IList<string>                              m_Units;
    #endregion
  };
  //---------------------------//

}  // namespace