﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Globalization;
//---------------------------//

namespace rr.Library.Helper
{
  public static class TStringHelper
  {
    public static string ZapSpace (string str)
    {
      if (str != null) {
        return (str.Replace (" ", string.Empty));
      }

      return (string.Empty);
    }

    public static bool IsStringEmpty (string str)
    {
      if (string.IsNullOrEmpty (str)) {
        return (true);
      }

      string some = str.Trim ();

      if (string.IsNullOrEmpty (some)) {
        return (true);
      }

      return (false);
    }

    public static bool IsStringAlphanumeric (string str)
    {
      if (str == null) {
        return (false);
      }

      bool ret = true;

      if (str == NumberFormatInfo.CurrentInfo.CurrencyDecimalSeparator |
          str == NumberFormatInfo.CurrentInfo.CurrencyGroupSeparator |
          str == NumberFormatInfo.CurrentInfo.CurrencySymbol |
          str == NumberFormatInfo.CurrentInfo.NegativeSign |
          str == NumberFormatInfo.CurrentInfo.NegativeInfinitySymbol |
          str == NumberFormatInfo.CurrentInfo.NumberDecimalSeparator |
          str == NumberFormatInfo.CurrentInfo.NumberGroupSeparator |
          str == NumberFormatInfo.CurrentInfo.PercentDecimalSeparator |
          str == NumberFormatInfo.CurrentInfo.PercentGroupSeparator |
          str == NumberFormatInfo.CurrentInfo.PercentSymbol |
          str == NumberFormatInfo.CurrentInfo.PerMilleSymbol |
          str == NumberFormatInfo.CurrentInfo.PositiveInfinitySymbol |
          str == NumberFormatInfo.CurrentInfo.PositiveSign) {
        return (ret == false);
      }

      int len = str.Length;

      for (int i = 0; i < len; i++) {
        char ch = str [i];

        if (Char.IsWhiteSpace (ch)) {
          continue;
        }

        ret &= Char.IsLetterOrDigit (ch);
      }

      return (ret);
    }
  }
  //---------------------------//

}  // namespace