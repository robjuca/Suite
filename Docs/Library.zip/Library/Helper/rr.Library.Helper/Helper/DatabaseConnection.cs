﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Collections.Generic;

using rr.Library.Types;
//---------------------------//

namespace rr.Library.Helper
{
  public class TDatabaseConnection
  {
    #region Property
    public bool IsValidate
    {
      get
      {
        return (CurrentDatabase.HasConnectionString);
      }
    }

    public TAuthentication Authentication
    {
      get;
      private set;
    }

    public bool IsAuthentication
    {
      get
      {
        return (Authentication != TAuthentication.None);
      }
    }

    public TDatabaseAuthentication CurrentDatabase
    {
      get
      {
        return (IsAuthentication ? Databases [Authentication] : TDatabaseAuthentication.CreateDefault);
      }
    }

    public TValidationResult Result
    {
      get;
      private set;
    }
    #endregion

    #region Constructor
    TDatabaseConnection ()
    {
      IniFileManager = TIniFileManager.CreatDefault;

      Databases = new Dictionary<TAuthentication, TDatabaseAuthentication>
      {
        { TAuthentication.SQL, TDatabaseAuthentication.Create (TAuthentication.SQL) },
        { TAuthentication.Windows, TDatabaseAuthentication.Create (TAuthentication.Windows) }
      };

      Result = TValidationResult.CreateDefault;
    }

    public TDatabaseConnection (string filePath, string fileName)
      : this ()
    {
      IniFileManager.SelectPath (filePath, fileName);
    }
    #endregion

    #region Members
    public bool Request ()
    {
      Result = TValidationResult.Success;

      if (ValidateFile ()) {
        // SQL
        var db = Databases [TAuthentication.SQL];
        db.DatabaseServer = IniFileManager.RequestKey (SQLADBSection, DatabaseServer);
        db.DatabaseName = IniFileManager.RequestKey (SQLADBSection, DatabaseName);
        db.UserId = IniFileManager.RequestKey (SQLADBSection, UserId);
        db.UserPassword = IniFileManager.RequestKey (SQLADBSection, UserPassword);

        // Windows
        db = Databases [TAuthentication.Windows];
        db.DatabaseServer = IniFileManager.RequestKey (WADBSection, DatabaseServer);
        db.DatabaseName = IniFileManager.RequestKey (WADBSection, DatabaseName);

        // Authentication
        string authentication = IniFileManager.RequestKey (AuthenticationSection, AuthenticationType);

        Authentication = (TAuthentication) Enum.Parse (typeof (TAuthentication), authentication);

        foreach (var item in Databases) {
          item.Value.Activate (Authentication);
        }

        return (true);
      }

      return (false);
    }

    public bool Save (TDatabaseAuthentication databaseAuthentication)
    {
      Result = TValidationResult.Success;

      if (ValidateFile ()) {
        switch (databaseAuthentication.Authentication) {
          // SQL
          case TAuthentication.SQL: {
              var db = Databases [TAuthentication.SQL];
              db.Change (databaseAuthentication);

              KeyChange (TAuthentication.SQL);
            }

            break;

          // Windows
          case TAuthentication.Windows: {
              var db = Databases [TAuthentication.Windows];
              db.Change (databaseAuthentication);

              KeyChange (TAuthentication.Windows);
            }

            break;
        }

        // Authentication
        IniFileManager.ChangeKey (AuthenticationSection, AuthenticationType, TAuthentication.None.ToString ()); // default

        foreach (var item in Databases) {
          if (item.Value.IsActive) {
            IniFileManager.ChangeKey (AuthenticationSection, AuthenticationType, item.Value.Authentication.ToString ()); 
            break;
          }
        }

        IniFileManager.SaveChanges ();

        return (true);
      }

      return (false);
    }

    public TDatabaseAuthentication Request (TAuthentication authentication)
    {
      return (Databases [authentication]);
    }

    public void ChangeAuthentication (TAuthentication authentication)
    {
      Authentication = authentication;

      // Authentication
      IniFileManager.ChangeKey (AuthenticationSection, AuthenticationType, authentication.ToString ());
      IniFileManager.SaveChanges ();
    }
    #endregion

    #region Property
    TIniFileManager IniFileManager
    {
      get; 
    }

    Dictionary<TAuthentication, TDatabaseAuthentication> Databases
    {
      get;
    }
    #endregion

    #region Fields
    const string                            SQLADBSection = "SQLADBSection";
    const string                            WADBSection = "WADBSection";
    const string                            AuthenticationSection = "AuthenticationSection";

    const string                            DatabaseServer = "DatabaseServer";
    const string                            DatabaseName = "DatabaseName";
    const string                            UserId = "UserId";
    const string                            UserPassword = "UserPassword";

    const string                            AuthenticationType = "AuthenticationType";

    const string                            Validate = "Validate";
    const string                            IsValidated = "IsValidated";
    #endregion

    #region Support
    bool ValidateFile ()
    {
      Result = IniFileManager.ValidatePath ();

      // file not found
      if (Result.IsValid.IsFalse ()) {
        if (IniFileManager.IniFileExists ().IsFalse ()) {
          // create
          // SQL authentication section
          var db = Databases [TAuthentication.SQL];
          var sqlToken = IniFileManager.AddSection (SQLADBSection);
          IniFileManager.AddTrailingComment (sqlToken, "SQL authentication database connection data"); // comment.

          IniFileManager.AddKey (sqlToken, DatabaseServer, db.DatabaseServer); 
          IniFileManager.AddKey (sqlToken, DatabaseName, db.DatabaseName);
          IniFileManager.AddKey (sqlToken, UserId, db.UserId);
          IniFileManager.AddKey (sqlToken, UserPassword, db.UserPassword);

          // Windows authentication section
          db = Databases [TAuthentication.Windows];
          var windowToken = IniFileManager.AddSection (WADBSection);
          IniFileManager.AddTrailingComment (windowToken, "Windows authentication database connection data"); // comment.

          IniFileManager.AddKey (windowToken, DatabaseServer, db.DatabaseServer);
          IniFileManager.AddKey (windowToken, DatabaseName, db.DatabaseName);

          // Authentication section
          var authToken = IniFileManager.AddSection (AuthenticationSection);
          IniFileManager.AddTrailingComment (authToken, "Authentication database type"); // comment.

          IniFileManager.AddKey (authToken, AuthenticationType, TAuthentication.SQL.ToString ()); //  by default

          IniFileManager.SaveChanges ();
        }
      }

      return (true);
    }

    void KeyChange (TAuthentication authentication)
    {
      switch (authentication) {
        case TAuthentication.SQL: {
            var db = Databases [TAuthentication.SQL];

            IniFileManager.ChangeKey (SQLADBSection, DatabaseServer, db.DatabaseServer);
            IniFileManager.ChangeKey (SQLADBSection, DatabaseName, db.DatabaseName);
            IniFileManager.ChangeKey (SQLADBSection, UserId, db.UserId);
            IniFileManager.ChangeKey (SQLADBSection, UserPassword, db.UserPassword);
          }

          break;

        case TAuthentication.Windows: {
            var db = Databases [TAuthentication.Windows];

            IniFileManager.ChangeKey (WADBSection, DatabaseServer, db.DatabaseServer);
            IniFileManager.ChangeKey (WADBSection, DatabaseName, db.DatabaseName);
          }

          break;
      }
    }
    #endregion
  };
  //---------------------------//

}  // namespace