﻿/*----------------------------------------------------------------
  Copyright (C) 2001 R&R Soft - All rights reserved.
  author: Roberto Oliveira Jucá    
----------------------------------------------------------------*/

//----- Include
using System;
using System.Collections.Generic;

using MadMilkman.Ini;

using rr.Library.Types;
//---------------------------//

namespace rr.Library.Helper
{
  public class TDatabaseConnection
  {
    #region Property
    public string FilePath
    {
      get;
      private set;
    }

    public string FileName
    {
      get;
      private set;
    }

    public bool IsValidate
    {
      get
      {
        return (CurrentDatabase.HasConnectionString);
      }
    }

    public TAuthentication Authentication
    {
      get;
      private set;
    }

    public bool IsAuthentication
    {
      get
      {
        return (Authentication != TAuthentication.None);
      }
    }

    public TDatabaseAuthentication CurrentDatabase
    {
      get
      {
        return (IsAuthentication ? Databases [Authentication] : TDatabaseAuthentication.CreateDefault);
      }
    }
    public TValidationResult Result
    {
      get;
      private set;
    }
    #endregion

    #region Constructor
    public TDatabaseConnection ()
    {
      Databases = new Dictionary<TAuthentication, TDatabaseAuthentication>
      {
        { TAuthentication.SQL, TDatabaseAuthentication.Create (TAuthentication.SQL) },
        { TAuthentication.Windows, TDatabaseAuthentication.Create (TAuthentication.Windows) }
      };

      Result = TValidationResult.CreateDefault;

      var options = new IniOptions
      {
        SectionDuplicate = IniDuplication.Disallowed
      };

      IniFileManager = new IniFile (options);
      IniFileManager.ValueMappings.Add ("True", true);
      IniFileManager.ValueMappings.Add ("False", false);
    }

    public TDatabaseConnection (string filePath, string fileName)
      : this ()
    {
      FilePath = filePath;
      FileName = fileName;
    }
    #endregion

    #region Members
    public bool ValidateFile ()
    {
      Result = TValidationResult.Success;

      if (string.IsNullOrWhiteSpace ((FilePath ?? "").ToString ()) || string.IsNullOrWhiteSpace ((FileName ?? "").ToString ())) {
        Result = new TValidationResult ("FilePath or FileName is NULL or EMPTY!");
        return (false);
      }

      if (System.IO.Directory.Exists (FilePath).Equals (false)) {
        Result = new TValidationResult ("FilePath does not exist!");
        return (false);
      }

      var fullPath = System.IO.Path.Combine (FilePath, FileName);

      // file not found
      if (System.IO.File.Exists (fullPath).Equals (false)) {
        // create
        // SQL authentication section
        var db = Databases [TAuthentication.SQL];
        IniSection sqlSection = IniFileManager.Sections.Add (SQLADBSection);
        sqlSection.TrailingComment.Text = "SQL authentication database connection data"; // comment.

        sqlSection.Keys.Add (DatabaseServer, db.DatabaseServer);
        sqlSection.Keys.Add (DatabaseName, db.DatabaseName);
        sqlSection.Keys.Add (UserId, db.UserId);
        sqlSection.Keys.Add (UserPassword, db.UserPassword);

        // Windows authentication section
        db = Databases [TAuthentication.Windows];
        IniSection wSection = IniFileManager.Sections.Add (WADBSection);
        wSection.TrailingComment.Text = "Windows authentication database connection data"; // comment.

        wSection.Keys.Add (DatabaseServer, db.DatabaseServer);
        wSection.Keys.Add (DatabaseName, db.DatabaseName);

        // Authentication section
        IniSection section = IniFileManager.Sections.Add (AuthenticationSection);
        section.TrailingComment.Text = "Authentication database type"; // comment.

        section.Keys.Add (AuthenticationType, TAuthentication.SQL.ToString ()); //  by default

        // Validate
        //section = m_IniFile.Sections.Add (Validate);
        //section.TrailingComment.Text = "database connection data validation"; // comment.

        //section.Keys.Add (IsValidated, ConnectionData.IsValidated.ToString ());

        IniFileManager.Save (fullPath);
      }

      else {
        if (IsIniFileManagerLoaded.Equals (false)) {
          IniFileManager.Load (fullPath);
        }
      }

      return (true);
    }

    public bool Request ()
    {
      Result = TValidationResult.Success;

      if (ValidateFile ()) {
        // SQL
        var db = Databases [TAuthentication.SQL];
        db.DatabaseServer = KeyValue (SQLADBSection, DatabaseServer);
        db.DatabaseName = KeyValue (SQLADBSection, DatabaseName);
        db.UserId = KeyValue (SQLADBSection, UserId);
        db.UserPassword = KeyValue (SQLADBSection, UserPassword);

        // Windows
        db = Databases [TAuthentication.Windows];
        db.DatabaseServer = KeyValue (WADBSection, DatabaseServer);
        db.DatabaseName = KeyValue (WADBSection, DatabaseName);

        // Authentication
        string authentication = KeyValue (AuthenticationSection, AuthenticationType);

        Authentication = (TAuthentication) Enum.Parse (typeof (TAuthentication), authentication);

        foreach (var item in Databases) {
          item.Value.Activate (Authentication);
        }

        

        //section = m_IniFile.Sections [Validate];
        //section.Keys [IsValidated].TryParseValue (out bool validate);
        //IsValidate = validate;

        return (true);
      }

      return (false);
    }

    public bool Save (TDatabaseAuthentication databaseAuthentication)
    {
      Result = TValidationResult.Success;

      if (ValidateFile ()) {
        switch (databaseAuthentication.Authentication) {
          // SQL
          case TAuthentication.SQL: {
              var db = Databases [TAuthentication.SQL];
              db.Change (databaseAuthentication);

              KeyChange (TAuthentication.SQL);
            }

            break;

          // Windows
          case TAuthentication.Windows: {
              var db = Databases [TAuthentication.Windows];
              db.Change (databaseAuthentication);

              KeyChange (TAuthentication.Windows);
            }

            break;
        }

        // Authentication
        KeyChange (AuthenticationSection, AuthenticationType, TAuthentication.None.ToString ()); // default

        foreach (var item in Databases) {
          if (item.Value.IsActive) {
            KeyChange (AuthenticationSection, AuthenticationType, item.Value.Authentication.ToString ()); 
            break;
          }
        }

        SaveChanges ();

        return (true);
      }

      return (false);
    }

    public TDatabaseAuthentication Request (TAuthentication authentication)
    {
      return (Databases [authentication]);
    }

    public void ChangeAuthentication (TAuthentication authentication)
    {
      Authentication = authentication;

      // Authentication
      KeyChange (AuthenticationSection, AuthenticationType, authentication.ToString ());

      SaveChanges ();
    }

    public bool SelectValidate (bool validate)
    {
      var res = false;

      //Result = TValidationResult.Success;

      //if (ValidateFile ()) {
      //  // read file
      //  var fullPath = System.IO.Path.Combine (FilePath, FileName);
      //  m_IniFile.Load (fullPath);

      //  IniSection section = m_IniFile.Sections [Validate];
      //  section.Keys.Clear ();

      //  section.Keys.Add (IsValidated, validate.ToString ());

      //  m_IniFile.Save (fullPath);

      //  IsValidate = validate;

      //  res = true;
      //}

      return (res);
    }
    #endregion

    #region Property
    Dictionary<TAuthentication, TDatabaseAuthentication> Databases
    {
      get;
    }

    IniFile IniFileManager
    {
      get;
    }

    bool IsIniFileManagerLoaded
    {
      get
      {
        return (IniFileManager.Sections.Count > 0);
      }
    }
    #endregion

    #region Fields
    const string                            SQLADBSection = "SQLADBSection";
    const string                            WADBSection = "WADBSection";
    const string                            AuthenticationSection = "AuthenticationSection";

    const string                            DatabaseServer = "DatabaseServer";
    const string                            DatabaseName = "DatabaseName";
    const string                            UserId = "UserId";
    const string                            UserPassword = "UserPassword";

    const string                            AuthenticationType = "AuthenticationType";

    const string                            Validate = "Validate";
    const string                            IsValidated = "IsValidated";
    #endregion

    #region Support
    IniSection Section (string section)
    {
      return (IniFileManager.Sections [section]);
    }

    string KeyValue (string section, string key)
    {
      return (Section (section).Keys [key].Value);
    }

    void KeyChange (string section, string key, string value)
    {
      Section (section).Keys [key].Value = value;
    }

    void KeyChange (TAuthentication authentication)
    {
      switch (authentication) {
        case TAuthentication.SQL: {
            var db = Databases [TAuthentication.SQL];

            KeyChange (SQLADBSection, DatabaseServer, db.DatabaseServer);
            KeyChange (SQLADBSection, DatabaseName, db.DatabaseName);
            KeyChange (SQLADBSection, UserId, db.UserId);
            KeyChange (SQLADBSection, UserPassword, db.UserPassword);
          }

          break;

        case TAuthentication.Windows: {
            var db = Databases [TAuthentication.Windows];

            KeyChange (WADBSection, DatabaseServer, db.DatabaseServer);
            KeyChange (WADBSection, DatabaseName, db.DatabaseName);
          }

          break;
      }
    }

    void SaveChanges ()
    {
      var fullPath = System.IO.Path.Combine (FilePath, FileName);
      IniFileManager.Save (fullPath);
    }
    #endregion
  };
  //---------------------------//

}  // namespace